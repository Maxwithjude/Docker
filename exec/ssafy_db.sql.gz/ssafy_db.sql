-- Adminer 4.8.1 MySQL 8.4.4 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

CREATE DATABASE `ssafy_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `ssafy_db`;

CREATE TABLE `bookmark_tag` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `bookmark_id` bigint DEFAULT NULL,
  `tag_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4ima26acldi5fb4ik9qb9sk6c` (`bookmark_id`),
  KEY `FKhq7j2vott6kem0g51hhgq5nfl` (`tag_id`),
  CONSTRAINT `FK4ima26acldi5fb4ik9qb9sk6c` FOREIGN KEY (`bookmark_id`) REFERENCES `bookmarks` (`id`),
  CONSTRAINT `FKhq7j2vott6kem0g51hhgq5nfl` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `bookmark_url` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `reading_time` int DEFAULT NULL,
  `reference_count` bigint NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `url` varchar(4096) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `bookmark_url_tag` (
  `bookmark_url_id` bigint NOT NULL,
  `tag_id` bigint NOT NULL,
  PRIMARY KEY (`bookmark_url_id`,`tag_id`),
  KEY `FK89dm5f7lfqh3pp5k4stfmtf1c` (`tag_id`),
  CONSTRAINT `FK87eb8uwwjdtmev416yxlc8r7` FOREIGN KEY (`bookmark_url_id`) REFERENCES `bookmark_url` (`id`),
  CONSTRAINT `FK89dm5f7lfqh3pp5k4stfmtf1c` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `bookmarks` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `is_read` bit(1) NOT NULL,
  `priority` bit(1) NOT NULL,
  `url_id` bigint NOT NULL,
  `personal_collection_id` bigint DEFAULT NULL,
  `shared_collection_id` bigint DEFAULT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKbr351s5pxnh4e1wpdwfylxhsp` (`url_id`),
  KEY `FK6h6aj644yvg8c6afhtqqte447` (`personal_collection_id`),
  KEY `FKg8ly42d5j04wlcfckpg3j8nef` (`shared_collection_id`),
  KEY `FKab3b25rlka2y5um0u2a3b7jcu` (`user_id`),
  CONSTRAINT `FK6h6aj644yvg8c6afhtqqte447` FOREIGN KEY (`personal_collection_id`) REFERENCES `personal_collection` (`id`),
  CONSTRAINT `FKab3b25rlka2y5um0u2a3b7jcu` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKbr351s5pxnh4e1wpdwfylxhsp` FOREIGN KEY (`url_id`) REFERENCES `bookmark_url` (`id`),
  CONSTRAINT `FKg8ly42d5j04wlcfckpg3j8nef` FOREIGN KEY (`shared_collection_id`) REFERENCES `shared_collection` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `memo` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `content` varchar(255) NOT NULL,
  `bookmark_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKbq7lt8ju7wa4lq39p4xucyyh7` (`bookmark_id`),
  KEY `FK5vlmhksso19pshk0ac1qo1p82` (`user_id`),
  CONSTRAINT `FK5vlmhksso19pshk0ac1qo1p82` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKbq7lt8ju7wa4lq39p4xucyyh7` FOREIGN KEY (`bookmark_id`) REFERENCES `bookmarks` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `notification` (
  `type` varchar(31) NOT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `message` varchar(255) NOT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `bookmark_id` bigint DEFAULT NULL,
  `shared_collection_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKb0yvoep4h4k92ipon31wmdf7e` (`user_id`),
  KEY `FK8btbera9j8sxy2ksjqshbvkfg` (`bookmark_id`),
  KEY `FK4ala52wxk72wufncrtvqq45we` (`shared_collection_id`),
  CONSTRAINT `FK4ala52wxk72wufncrtvqq45we` FOREIGN KEY (`shared_collection_id`) REFERENCES `shared_collection` (`id`),
  CONSTRAINT `FK8btbera9j8sxy2ksjqshbvkfg` FOREIGN KEY (`bookmark_id`) REFERENCES `bookmarks` (`id`),
  CONSTRAINT `FKb0yvoep4h4k92ipon31wmdf7e` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `personal_collection` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `name` varchar(20) NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKroo2w7fjh72wu99ytavoduhas` (`user_id`),
  CONSTRAINT `FKroo2w7fjh72wu99ytavoduhas` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `rss` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `rss_url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `s3_image` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `file_key` varchar(300) NOT NULL,
  `file_url` varchar(300) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKfgw38idbsw7oe7s22m3wyecac` (`file_key`),
  UNIQUE KEY `UKdv7ma81yd6jyfdqf16r4apnaf` (`file_url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `shared_collection` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `shared_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `role` enum('MEMBER','OWNER') NOT NULL,
  `shared_collection_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKll32xt96y95gh07qkf0ohevrk` (`shared_collection_id`),
  KEY `FKj0aseyosg5np7kowhfqescdlx` (`user_id`),
  CONSTRAINT `FKj0aseyosg5np7kowhfqescdlx` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKll32xt96y95gh07qkf0ohevrk` FOREIGN KEY (`shared_collection_id`) REFERENCES `shared_collection` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `shared_user` (`id`, `created_at`, `updated_at`, `role`, `shared_collection_id`, `user_id`) VALUES
(1,	'2025-02-19 10:44:56.000000',	'2025-02-19 10:44:56.000000',	'OWNER',	1,	1),
(3,	'2025-02-19 10:44:56.000000',	'2025-02-19 10:44:56.000000',	'MEMBER',	1,	3),
(4,	'2025-02-19 10:44:56.000000',	'2025-02-19 10:44:56.000000',	'MEMBER',	1,	4),
(5,	'2025-02-19 10:44:56.000000',	'2025-02-19 10:44:56.000000',	'MEMBER',	1,	5),
(6,	'2025-02-19 10:44:56.000000',	'2025-02-19 10:44:56.000000',	'OWNER',	2,	1),
(7,	'2025-02-19 10:44:56.000000',	'2025-02-19 10:44:56.000000',	'MEMBER',	2,	2),
(8,	'2025-02-19 10:44:56.000000',	'2025-02-19 10:44:56.000000',	'MEMBER',	2,	3),
(9,	'2025-02-19 10:44:56.000000',	'2025-02-19 10:44:56.000000',	'MEMBER',	2,	4),
(10,	'2025-02-19 10:44:56.000000',	'2025-02-19 10:44:56.000000',	'OWNER',	3,	5),
(11,	'2025-02-19 10:44:56.000000',	'2025-02-19 10:44:56.000000',	'MEMBER',	3,	1),
(12,	'2025-02-20 06:44:37.191459',	'2025-02-20 06:44:37.191459',	'MEMBER',	1,	2),
(13,	'2025-02-20 12:45:25.000000',	'2025-02-20 12:45:25.000000',	'OWNER',	13,	8),
(14,	'2025-02-20 12:45:25.000000',	'2025-02-20 12:45:25.000000',	'MEMBER',	13,	1),
(15,	'2025-02-20 12:45:25.000000',	'2025-02-20 12:45:25.000000',	'MEMBER',	13,	2),
(16,	'2025-02-20 12:45:25.000000',	'2025-02-20 12:45:25.000000',	'MEMBER',	13,	7),
(17,	'2025-02-20 12:45:25.000000',	'2025-02-20 12:45:25.000000',	'MEMBER',	13,	10),
(18,	'2025-02-20 12:55:35.000000',	'2025-02-20 12:55:35.000000',	'MEMBER',	14,	8),
(19,	'2025-02-20 12:55:35.000000',	'2025-02-20 12:55:35.000000',	'OWNER',	14,	1),
(20,	'2025-02-20 12:55:35.000000',	'2025-02-20 12:55:35.000000',	'MEMBER',	14,	4),
(21,	'2025-02-20 12:55:35.000000',	'2025-02-20 12:55:35.000000',	'MEMBER',	14,	6),
(22,	'2025-02-20 12:56:16.000000',	'2025-02-20 12:56:16.000000',	'MEMBER',	15,	1),
(23,	'2025-02-20 12:56:16.000000',	'2025-02-20 12:56:16.000000',	'OWNER',	15,	2),
(24,	'2025-02-20 12:56:16.000000',	'2025-02-20 12:56:16.000000',	'MEMBER',	15,	3),
(25,	'2025-02-20 12:56:16.000000',	'2025-02-20 12:56:16.000000',	'MEMBER',	15,	4),
(26,	'2025-02-20 12:56:16.000000',	'2025-02-20 12:56:16.000000',	'MEMBER',	15,	5),
(27,	'2025-02-20 12:56:16.000000',	'2025-02-20 12:56:16.000000',	'MEMBER',	15,	6),
(28,	'2025-02-20 12:56:16.000000',	'2025-02-20 12:56:16.000000',	'MEMBER',	15,	7),
(29,	'2025-02-20 12:56:16.000000',	'2025-02-20 12:56:16.000000',	'MEMBER',	15,	8),
(30,	'2025-02-20 12:56:16.000000',	'2025-02-20 12:56:16.000000',	'MEMBER',	15,	9),
(31,	'2025-02-20 12:56:16.000000',	'2025-02-20 12:56:16.000000',	'MEMBER',	15,	10),
(32,	'2025-02-20 19:31:49.844522',	'2025-02-20 19:31:49.844522',	'OWNER',	16,	1);

CREATE TABLE `tag` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `bolder_color` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `reference_count` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK1wdpsed5kna2y38hnbgrnhi5b` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `access_token` varchar(255) DEFAULT NULL,
  `alert_day` int NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `email_verification_token` varchar(255) DEFAULT NULL,
  `is_active` enum('PENDING','ACTIVE','INACTIVE','LOCKED') NOT NULL DEFAULT 'PENDING',
  `is_verified` bit(1) NOT NULL,
  `nickname` varchar(20) NOT NULL,
  `password` varchar(256) NOT NULL,
  `profile_url` varchar(500) NOT NULL,
  `provider` enum('LOCAL','KAKAO','NAVER','GOOGLE') NOT NULL DEFAULT 'LOCAL',
  `provider_id` varchar(60) DEFAULT NULL,
  `refresh_token` varchar(255) DEFAULT NULL,
  `role` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKob8kqyqqgmefl0aco34akdtpe` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `user_rss` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `is_read` bit(1) NOT NULL,
  `latest_title` varchar(255) DEFAULT NULL,
  `previous_title` varchar(255) DEFAULT NULL,
  `rss_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3ukjkuyxu1x28posygm7g2q0r` (`rss_id`),
  KEY `FK59cs7l8b2kkj75ir5ubi4vhko` (`user_id`),
  CONSTRAINT `FK3ukjkuyxu1x28posygm7g2q0r` FOREIGN KEY (`rss_id`) REFERENCES `rss` (`id`),
  CONSTRAINT `FK59cs7l8b2kkj75ir5ubi4vhko` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `user_tag` (
  `tag_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`tag_id`,`user_id`),
  KEY `FKhqbypqh9kyjp3jcslfg67c6n5` (`user_id`),
  CONSTRAINT `FK9qknt3y115f17660k0qnm9x3g` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`id`),
  CONSTRAINT `FKhqbypqh9kyjp3jcslfg67c6n5` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- 2025-02-21 01:25:26
